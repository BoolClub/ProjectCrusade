using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Ziggyware;

namespace Shadows2D
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class  GraphicsExp: Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Vector2 lightPosition;
        Vector2 lightPosition2;
        Texture2D testTexture;
        Texture2D tileTexture;
        QuadRenderComponent quadRender;
        TestObject testObject;
        ShadowmapResolver shadowmapResolver;
        LightArea lightArea1;
        LightArea lightArea2;
        RenderTarget2D screenShadows;

        public GraphicsExp()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            this.IsFixedTimeStep = false;
            graphics.SynchronizeWithVerticalRetrace = false;
            graphics.PreferredBackBufferWidth = 800;
            graphics.PreferredBackBufferHeight = 600;
            quadRender = new QuadRenderComponent(this);
            this.Components.Add(quadRender);
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            shadowmapResolver = new ShadowmapResolver(GraphicsDevice, quadRender, ShadowmapSize.Size256, ShadowmapSize.Size1024);
            shadowmapResolver.LoadContent(Content);
            lightArea1 = new LightArea(GraphicsDevice, ShadowmapSize.Size512);
            lightArea2 = new LightArea(GraphicsDevice, ShadowmapSize.Size512);
            // Create a new SpriteBatch, which can be used to draw textures.
            testTexture = Content.Load<Texture2D>("Circle");
            tileTexture = Content.Load<Texture2D>("Stone tile");
            lightPosition = new Vector2(276, 276);
            lightPosition2 = new Vector2(560, 154);
            screenShadows = new RenderTarget2D(GraphicsDevice, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);

            //load texture
            Texture2D texture = Content.Load<Texture2D>("ANIMATION_SHEET");

            //create object
            testObject = new TestObject(texture, 14, new Vector2(64, 128));

            //place it in the center of the screen
            testObject.Position = new Vector2(600, 300);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            Vector2 movement = GamePad.GetState(PlayerIndex.One).ThumbSticks.Left;
            movement.Y *= -1.0f;

            Vector2 movement2 = GamePad.GetState(PlayerIndex.One).ThumbSticks.Right;
            movement2.Y *= -1.0f;

            KeyboardState ks = Keyboard.GetState();
            if (ks.IsKeyDown(Keys.Left))
                movement.X = -1.0f;

            if (ks.IsKeyDown(Keys.Right))
                movement.X = 1.0f;
            if (ks.IsKeyDown(Keys.Up))
                movement.Y = -1.0f;
            if (ks.IsKeyDown(Keys.Down))
                movement.Y = 1.0f;

            lightPosition += movement * 100.0f * (float)gameTime.ElapsedGameTime.TotalSeconds;
            lightPosition2 += movement2 * 100.0f * (float)gameTime.ElapsedGameTime.TotalSeconds;

            //update object's state
            testObject.Update(gameTime);

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            //first light area
            lightArea1.LightPosition = lightPosition;
            lightArea1.BeginDrawingShadowCasters();
            DrawCasters(lightArea1);
            lightArea1.EndDrawingShadowCasters();
            shadowmapResolver.ResolveShadows(lightArea1.RenderTarget, lightArea1.RenderTarget, lightPosition);

            //second light area
            lightArea2.LightPosition = lightPosition2;
            lightArea2.BeginDrawingShadowCasters();
            DrawCasters(lightArea2);
            lightArea2.EndDrawingShadowCasters();
            shadowmapResolver.ResolveShadows(lightArea2.RenderTarget, lightArea2.RenderTarget, lightPosition2);
            

            GraphicsDevice.SetRenderTarget(screenShadows);
            GraphicsDevice.Clear(Color.Black);
            spriteBatch.Begin(SpriteSortMode.Deferred,BlendState.Additive);
            spriteBatch.Draw(lightArea1.RenderTarget, lightArea1.LightPosition - lightArea1.LightAreaSize * 0.5f, Color.Red);
            spriteBatch.Draw(lightArea2.RenderTarget, lightArea2.LightPosition - lightArea2.LightAreaSize * 0.5f, Color.Blue);
            spriteBatch.End();

            GraphicsDevice.SetRenderTarget(null);


            GraphicsDevice.Clear(Color.Black);

            DrawGround();

            BlendState blendState = new BlendState();
            blendState.ColorSourceBlend = Blend.DestinationColor;
            blendState.ColorDestinationBlend = Blend.SourceColor;

            spriteBatch.Begin(SpriteSortMode.Immediate, blendState);
            spriteBatch.Draw(screenShadows, Vector2.Zero, Color.White);
            spriteBatch.End();

            DrawScene();

            base.Draw(gameTime);
        }

        private void DrawCasters(LightArea lightArea)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(testTexture, lightArea.ToRelativePosition(Vector2.Zero), Color.Black);
            testObject.Draw(spriteBatch, lightArea.ToRelativePosition(testObject.Position), Color.Black);
            spriteBatch.End();
        }

        private void DrawScene()
        {
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend);
            spriteBatch.Draw(testTexture, new Rectangle(0, 0, 512, 512), new Color(new Vector4(1, 1, 1, 1.0f)));
			testObject.Draw(spriteBatch, testObject.Position, Color.White);
            spriteBatch.End();
        }
        private void DrawGround()
        {
            //draw the tile texture tiles across the screen
            Rectangle source = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.Opaque, SamplerState.LinearWrap, DepthStencilState.Default, RasterizerState.CullNone);
            spriteBatch.Draw(tileTexture, Vector2.Zero, source, Color.White, 0, Vector2.Zero, 1.0f, SpriteEffects.None, 1.0f);
            spriteBatch.End();

        }
    }
}
